import Grapick from './Grapick'

module.exports = (o) => new Grapick(o)
